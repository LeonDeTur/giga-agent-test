"""Shared backend services."""
