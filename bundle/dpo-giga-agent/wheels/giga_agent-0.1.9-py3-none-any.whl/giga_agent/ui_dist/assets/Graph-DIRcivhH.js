import{s as t}from"./rolldown-runtime-BgcJHyDD.js";import{d as e,p as r}from"./langchain-BRntFIBE.js";import{jt as o}from"./lucide-react-sjuWK90a.js";import{t as a}from"./styled-components.browser.esm-C1Zvnb8n.js";import{n as i}from"./api-client-XDtpSvir.js";import{a as s,i as l,r as n,t as d}from"./use-dark-mode-DYfiHpu_.js";import{n as c,t as u}from"./plotly-CRXo1-AT.js";var p=t(r(),1),h=t(u(),1),g=t(c(),1),f=t(e(),1),m=(h.default.default??h.default)(g.default.default??g.default),b=a.div`
  width: 100%;
  padding-top: 56.25%; /* подложка под изображение, чтобы не прыгал layout */
  background-color: #2d2d2d;
  position: relative;
`,x=a.div`
  position: relative;
  width: 100%;
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  height: ${({$height:t})=>`${t}px`};
`,y=a.div`
  position: absolute;
  top: 0;
  left: 0;
  width: ${({$width:t})=>`${t}px`};
  height: ${({$height:t})=>`${t}px`};
  transform: scale(${({$scale:t})=>t});
  transform-origin: top left;
  .modebar-container,
  .modebar .modebar-group {
    background: rgba(0, 0, 0, 0) !important;
  }
`,$=a.div`
  position: relative;
`,w=a.button`
  position: absolute;
  top: ${({$isGraph:t})=>t?"40px":"8px"};
  right: 8px;
  width: 24px;
  height: 24px;
  z-index: 5;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: ${({$selected:t})=>t?"#1976d2":"transparent"};
  border: ${({$selected:t})=>t?"1px solid #1976d2":"1px solid #fff"};
  color: #fff;
  box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.2);
  @media print {
    display: none;
  }

  &:hover {
    transform: scale(1.05);
  }
`,j=({id:t,alt:e,path:r})=>{const[a,c]=(0,p.useState)(null),[u,h]=(0,p.useState)(!1);(0,p.useEffect)(()=>{let t=!1;return c(null),h(!1),(async()=>{try{const e=await i.getTextWithRedirectInstruction(l(r),{attachAuth:!0,credentials:"same-origin",showError:!1}),o=JSON.parse(e);t||(c(o),h(!1))}catch{t||h(!0)}})(),()=>{t=!0}},[r]);const g=d(),{isSelected:j,toggle:v}=n(),z=j(t),k=(0,p.useMemo)(()=>{const t=Number(a?.layout?.width);return t>0?t:700},[a]),_=(0,p.useMemo)(()=>{const t=Number(a?.layout?.height);return t>0?t:Math.round(k/(16/9))},[a,k]),M=(0,p.useRef)(null),[S,E]=(0,p.useState)(1);(0,p.useLayoutEffect)(()=>{if(!M.current)return;const t=M.current,e=()=>{const e=t.clientWidth;e>0&&E(Math.min(1,e/k))};e();const r=new ResizeObserver(e);return r.observe(t),()=>r.disconnect()},[k,a]);const N=(0,p.useMemo)(()=>{if(!a)return null;const t={...a.layout,autosize:!1,width:k,height:_};return g?{...t,template:"plotly_dark",paper_bgcolor:"rgba(0,0,0,0)",plot_bgcolor:"rgba(0,0,0,0)",font:{color:"#fff"},xaxis:{...a.layout?.xaxis,gridcolor:"rgba(255,255,255,0.2)",zerolinecolor:"rgba(255,255,255,0.2)"},yaxis:{...a.layout?.yaxis,gridcolor:"rgba(255,255,255,0.2)",zerolinecolor:"rgba(255,255,255,0.2)"}}:{...t,template:"plotly_white",paper_bgcolor:"rgba(255,255,255,0)",plot_bgcolor:"rgba(255,255,255,0)",font:{color:"#111"},xaxis:{...a.layout?.xaxis,gridcolor:"rgba(0,0,0,0.15)",zerolinecolor:"rgba(0,0,0,0.15)"},yaxis:{...a.layout?.yaxis,gridcolor:"rgba(0,0,0,0.15)",zerolinecolor:"rgba(0,0,0,0.15)"}}},[a,g,k,_]);return u?(0,f.jsxs)("div",{children:["Ошибка загрузки вложения"," ",(0,f.jsx)("a",{href:s(r),target:"_blank",rel:"noopener noreferrer",children:t})]}):a?(0,f.jsxs)($,{children:[(0,f.jsx)(w,{"aria-label":"select-attachment","data-onboarding":"response-attachment-selector",$isGraph:!0,$selected:z,onClick:r=>{r.stopPropagation(),v(t,e)},children:z?(0,f.jsx)(o,{size:24}):null}),(0,f.jsx)(x,{ref:M,$height:_*S,children:(0,f.jsx)(y,{$scale:S,$width:k,$height:_,children:(0,f.jsx)(m,{data:a.data,layout:N,style:{width:k,height:_}})})})]}):(0,f.jsx)(b,{})};export{j as default};