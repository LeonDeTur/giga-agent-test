import{s as e}from"./rolldown-runtime-BgcJHyDD.js";import{d as r,f as o,p as t}from"./langchain-BRntFIBE.js";import{t as i}from"./styled-components.browser.esm-C1Zvnb8n.js";var n=e(t(),1),a=e(o(),1),s=i.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 8px;
`,d=i.img`
  width: 40px;
  height: 40px;
  object-fit: cover;
  border-radius: 4px;
`,c=i.div`
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background-color: var(--color-secondary);
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  &:hover {
    background-color: var(--color-secondary);
  }
`,l=i.button`
  background: none;
  border: none;
  color: #ff6b6b;
  cursor: pointer;
  padding: 0;
  font-size: 16px;
  line-height: 1;

  &:hover {
    color: #ff8787;
  }
`,p=i.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,g=i.img`
  max-width: 90%;
  max-height: 90vh;
  object-fit: contain;
`,u=i.div`
  width: 40px;
  height: 40px;
  background: conic-gradient(
    #4caf50 ${({progress:e})=>3.6*e}deg,
    #555 0deg
  );
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  color: white;
`,x=i.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
`,f=i.button`
  position: absolute;
  top: 20px;
  right: 20px;
  background: none;
  border: none;
  color: white;
  font-size: 24px;
  cursor: pointer;
  padding: 8px;
  border-radius: 4px;
  background-color: rgba(255, 255, 255, 0.1);

  &:hover {
    background-color: rgba(255, 255, 255, 0.2);
  }
`,b=e(r(),1),h=i.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
`,m=i.div`
  position: relative;
  max-width: 90%;
  max-height: 90%;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  overflow: auto;
`,v=({children:e,onClose:r,isVisible:o})=>{const t=n.useRef(null);return t.current||(t.current=document.createElement("div")),(0,n.useEffect)(()=>{const e=t.current;return document.body.appendChild(e),()=>{document.body.removeChild(e)}},[]),o?a.createPortal((0,b.jsxs)(h,{onClick:e=>{e.target===e.currentTarget&&r?.()},children:[(0,b.jsx)(m,{children:e}),(0,b.jsx)(f,{onClick:()=>r?.(),children:"×"})]}),t.current):null};export{f as a,p as c,u as i,x as l,c as n,g as o,s as r,d as s,v as t,l as u};